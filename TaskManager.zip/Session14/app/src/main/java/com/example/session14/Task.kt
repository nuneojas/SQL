package com.example.session14

data class Task(val id: Int=0, val title: String="", val description: String="")

